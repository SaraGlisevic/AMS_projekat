# RISCV_VHDL
**Development of simple RV32IMA instruction set pipelined processor core**
Code will be written in VHDL.
RV32I - Base Integer Instruction Set, 32-bit registers
    M - Standard Extension for Integer Multiplication and Division
    A - Standard Extension for Atomic Instructions


